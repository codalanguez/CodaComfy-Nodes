The Fairest by Coda Languez | Full Book Trailer

Install CodaComfy Nodes from Comfy Registry and set OPENROUTER_API_KEY for your ComfyUI server. Restart the server.

Copy thornfield-guide.jpg into your ComfyUI input folder, then open the JSON in ComfyUI. The included image is a frame from the finished film. You can also upload your own artwork in the opening and title image nodes.

Edit the three scenes, character cards, written and spoken title, and score prompt. Choose available models and supported durations before running. OpenRouter generation uses your account credits.
